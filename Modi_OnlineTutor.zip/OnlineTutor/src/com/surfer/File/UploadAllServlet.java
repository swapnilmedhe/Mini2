package com.surfer.File;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class UploadAllServlet
 */
@WebServlet("/UploadAllServlet")
@MultipartConfig
public class UploadAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UploadAllServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		int tid=Integer.parseInt(request.getParameter("tid"));
		int cid=Integer.parseInt(request.getParameter("courses"));
		System.out.println("courseNameId:"+cid);
		final Part filePart = request.getPart("file");
		int filetypeid=Integer.parseInt(request.getParameter("filetype"));
		System.out.println("FileType(pdf/image/video)Id:"+filetypeid);
		//c
		System.out.println(filePart.getContentType());
		
		/* For the Storing Image */
		if(filePart.getContentType().equals("image/jpeg"))
		{
			
		        String imgid = request.getParameter("imgid");
		 
		        InputStream pdfFileBytes = null;
		        final PrintWriter writer = response.getWriter();
		 
		        try {
		 
		        	System.out.println(filePart.getContentType());
		          if (!filePart.getContentType().equals("image/jpeg"))
		            {
		                       writer.println("<br/> Invalid File");
		                       return;
		            }
		 
		           else if (filePart.getSize()>1048576 ) { //2mb
		               {
		              writer.println("<br/> File size too big");
		              return;
		               }
		           }
		 
		            pdfFileBytes = filePart.getInputStream();  // to get the body of the request as binary data
		 
		            final byte[] bytes = new byte[pdfFileBytes.available()];
		             pdfFileBytes.read(bytes);  //Storing the binary data in bytes array.
		 
		            Connection  con=null;
		             Statement stmt=null;
		 
		               try {
		                     Class.forName("com.mysql.jdbc.Driver");
		                     con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		                  } catch (Exception e) {
		                        System.out.println(e);
		                        System.exit(0);
		                              }
		 
		              try {
		                  stmt = con.createStatement();
		                  //to create table with blob field (One time only)
		                 /* stmt.executeUpdate("CREATE TABLE Image (imgid varchar (10) not null , imagecontent MEDIUMBLOB, Primary key (imgid))");*/
		                  
		                
		              } catch (Exception e) {
		                        System.out.println("Tables already created, skipping table creation process");
		                        e.printStackTrace();
		                  }
		 
		                int success=0;
		              //  PreparedStatement pstmt = con.prepareStatement("INSERT INTO Image VALUES(?,?)");
		                String query = "insert into tutor_course values (?,?,?,?)";
		                PreparedStatement pstmt = con.prepareStatement(query);
		                //PreparedStatement pstmt = con.prepareStatement("update tutor_course set filedata=?  where course_id= ? and filetype=?");
		                //pstmt.setInt(1, courseid);
		               // pstmt.setString(1, fileTypeName);
		               
		                //Storing binary data in blob field.
		                pstmt.setInt(1, tid);
		                pstmt.setInt(2, cid);
		                pstmt.setBytes(3,bytes); 
		                pstmt.setInt(4, filetypeid);
		                success = pstmt.executeUpdate();
		                if(success>=1)
		                	
		                	System.out.println("image Stored");
		                 con.close(); 
		 
		                 writer.println("<br/> Image Successfully Stored");
		 
		        } catch (FileNotFoundException fnf) {
		            writer.println("You  did not specify a file to upload");
		            writer.println("<br/> ERROR: " + fnf.getMessage());
		 
		        } catch (SQLException e) {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        } finally {
		 
		            if (pdfFileBytes != null) {
		                pdfFileBytes.close();
		            }
		            if (writer != null) {
		                writer.close();
		            }
		        }
			
			
		}else if(filePart.getContentType().equals("application/pdf"))             /* Upload the Pdf   */
		{
			
			 final Part filePartP = request.getPart("file");
		        String bookId = request.getParameter("bookId");
		 
		        InputStream pdfFileBytes = null;
		        final PrintWriter writer = response.getWriter();
		 
		        try {
		 
		          if (!filePartP.getContentType().equals("application/pdf"))
		            {
		                       writer.println("<br/> Invalid File");
		                       return;
		            }
		 
		           else if (filePartP.getSize()>1048576 ) { //2mb
		               {
		              writer.println("<br/> File size too big");
		              return;
		               }
		           }
		 
		            pdfFileBytes = filePartP.getInputStream();  // to get the body of the request as binary data
		 
		            final byte[] bytes = new byte[pdfFileBytes.available()];
		             pdfFileBytes.read(bytes);  //Storing the binary data in bytes array.
		 
		            Connection  con=null;
		             Statement stmt=null;
		 
		               try {
		                     Class.forName("com.mysql.jdbc.Driver");
		                     con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
		                  } catch (Exception e) {
		                        System.out.println(e);
		                        System.exit(0);
		                              }
		 
		              try {
		                  stmt = con.createStatement();
		                  //to create table with blob field (One time only)
		                //  stmt.executeUpdate("CREATE TABLE Book (BookId varchar (10) not null , BookContent MEDIUMBLOB, Primary key (BookId))");
		 
		              } catch (Exception e) {
		                        System.out.println("Tables already created, skipping table creation process");
		                  }
		 
		                int success=0;
		                String query = "insert into tutor_course values (?,?,?,?)";
		                PreparedStatement pstmt = con.prepareStatement(query);
		                //PreparedStatement pstmt = con.prepareStatement("update tutor_course set filedata=?  where course_id= ? and filetype=?");
		                //pstmt.setInt(1, courseid);
		               // pstmt.setString(1, fileTypeName);
		               
		                //Storing binary data in blob field.
		                pstmt.setInt(1, tid);
		                pstmt.setInt(2, cid);
		                pstmt.setBytes(3,bytes); 
		                pstmt.setInt(4, filetypeid);
		                success = pstmt.executeUpdate();
		                if(success>=1)  System.out.println("pdf Stored");
		                 con.close(); 
		 
		                 writer.println("<br/> pdf Successfully Stored");
		 
		        } catch (FileNotFoundException fnf) {
		            writer.println("You  did not specify a file to upload");
		            writer.println("<br/> ERROR: " + fnf.getMessage());
		 
		        } catch (SQLException e) {
		            // TODO Auto-generated catch block
		            e.printStackTrace();
		        } finally {
		 
		            if (pdfFileBytes != null) {
		                pdfFileBytes.close();
		            }
		            if (writer != null) {
		                writer.close();
		            }
			
			
		}
		
		}
		
		
	}

}
