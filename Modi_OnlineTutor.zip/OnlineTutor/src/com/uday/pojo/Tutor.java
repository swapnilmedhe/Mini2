package com.uday.pojo;

public class Tutor {
	int tid;
	String phone,password,qual;
	int exp;
	
	public Tutor() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Tutor(String phone, String password, String qual, int exp) {
		super();
		this.phone = phone;
		this.password = password;
		this.qual = qual;
		this.exp = exp;
	}

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getQual() {
		return qual;
	}

	public void setQual(String qual) {
		this.qual = qual;
	}

	public int getExp() {
		return exp;
	}

	public void setExp(int exp) {
		this.exp = exp;
	}
	
	
	
	
}
