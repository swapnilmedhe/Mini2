package com.uday.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uday.daoImp.UserDaoImp;
import com.uday.pojo.User;

/**
 * Servlet implementation class UserRequestedDataController
 */
@WebServlet("/UserRequestedDataController")
public class UserRequestedDataController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 PrintWriter out = response.getWriter();
			 ArrayList<String> allFiles=null;
			boolean isReq;
			int tid=0,cid=0;
			
					UserDaoImp userDao = new UserDaoImp();
					tid= Integer.parseInt(request.getParameter("tid"));
					cid= Integer.parseInt(request.getParameter("cid"));
					int uid= Integer.parseInt(request.getParameter("uid"));
					int filetype=Integer.parseInt(request.getParameter("filetype"));
					
					try {
						// status = userDao.checkRequest(user.getUid(), tid,cid);
						allFiles =userDao.display(uid, tid, cid, filetype);
						 HttpSession session = request.getSession();
							session.setAttribute("ALLFILE", allFiles);
							
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					
					}
}
			
	

	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
