package com.uday.daoImp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.uday.dao.TutorDao;
import com.uday.pojo.PersonInfo;
import com.uday.pojo.Tutor;

import static com.uday.dbUtils.MyConnection.*;

public class TutorDaoImp implements TutorDao {

	

	PreparedStatement ps=null;
	ResultSet rs= null;
	Tutor tutor =new Tutor();
	static final Logger log = Logger.getLogger(TutorDaoImp.class);
	int status=0;
	
	
	@Override
	public boolean regTutor(Tutor tutor) throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("insert into tutor (phone, password, qual, exp) values(?,?,?,?)");
			ps.setString(1, tutor.getPhone());
			ps.setString(2, tutor.getPassword());
			ps.setString(3, tutor.getQual());
			ps.setInt(4, tutor.getExp());
			ps.executeUpdate(); 
			
			tutor= loginTutor(tutor.getPhone(), tutor.getPassword());
			
			ps= con.prepareStatement("insert into person_info values("+tutor.getTid()+",'','','','','')");
			status = ps.executeUpdate();
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally{
			try {
				ps.close();
			} catch (SQLException e) {
				log.error("SQLException in closing PreparedStatement");
			}
		//executing the query
		}
		if(status>0)
		{
			log.info("User registered with name = "+tutor.getPhone());
		return true;
		}
		else
		{
			System.out.println("Registration Failed");
			return false;
		}
	}

	@Override
	public Tutor loginTutor(String phone, String pass)throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select * from tutor where phone=? and password=?");
			ps.setString(1, phone);
			ps.setString(2, pass);
			rs = ps.executeQuery(); 
			 while (rs.next()) {
				 tutor.setTid(rs.getInt(1));
				 tutor.setPhone(rs.getString(2));
				 tutor.setPassword(rs.getString(3));
				 tutor.setQual(rs.getString(4));
				 tutor.setExp(rs.getInt(5));
			      }
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		 finally {
		      try {
		        rs.close();
		        ps.close();
		      } catch (SQLException e) {
		    	  log.error("SQLException in closing PreparedStatement");
		    	  log.error("SQLException in closing ResultSet");
		    	  log.error("SQLException in closing Established Connection");
		      }
		    }

		 return tutor;
	}

	@Override
	public ArrayList<PersonInfo> showRequest(int tid) throws Exception {
		ArrayList<PersonInfo> reqList = new ArrayList<>();
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select * from (select tutor_id,user_id,first,course.course_id,ctitle,status from course,(select tutor_id,user_id, first,course_id,status from person_info,request where person_info.pid=request.user_id) as reqdetails where course.course_id=reqdetails.course_id) as checkRequsest where tutor_id=?");
			ps.setInt(1, tid);
			rs = ps.executeQuery(); 
			 while (rs.next()) {
				 PersonInfo req = new PersonInfo();
				 req.setTid(rs.getInt(1));
				 req.setUid(rs.getInt(2));
				 req.setFname(rs.getString(3));
				 req.setCid(rs.getInt(4));
				 req.setCname(rs.getString(5));
				 req.setStatus(rs.getString(6));
				 reqList.add(req);
			      }
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		 finally {
		      try {
		        rs.close();
		        ps.close();
		      } catch (SQLException e) {
		    	  log.error("SQLException in closing PreparedStatement");
		    	  log.error("SQLException in closing ResultSet");
		    	  log.error("SQLException in closing Established Connection");
		      }
		    }

		 return reqList;
	}

	
	@Override
	public boolean approveReq(int tid, int uid, int cid) throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("update request set status='approved' where tutor_id=? and user_id=? and course_id=?");
			ps.setInt(1, tid);
			ps.setInt(2, uid);
			ps.setInt(3, cid);
			status = ps.executeUpdate();
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally{
			try {
				ps.close();
			} catch (SQLException e) {
				log.error("SQLException in closing PreparedStatement");
			}
		//executing the query
		}
		if(status>0)
		{
			log.info("Req approved by user: "+tid);
		return true;
		}
		else
		{
			System.out.println("Approval Failed");
			return false;
		}
	}

	
	@Override
	public boolean rejectReq(int tid, int uid, int cid) throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("update request set status='rejected' where tutor_id=? and user_id=? and course_id=?");
			ps.setInt(1, tid);
			ps.setInt(2, uid);
			ps.setInt(3, cid);
			status = ps.executeUpdate();
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally{
			try {
				ps.close();
			} catch (SQLException e) {
				log.error("SQLException in closing PreparedStatement");
			}
		//executing the query
		}
		if(status>0)
		{
			log.info("Req rejected by user: "+tid);
		return true;
		}
		else
		{
			System.out.println("Rejection Failed");
			return false;
		}
	}



}
