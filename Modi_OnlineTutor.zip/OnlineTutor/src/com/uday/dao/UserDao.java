package com.uday.dao;

import java.util.ArrayList;

import com.uday.pojo.PersonInfo;
import com.uday.pojo.User;

public interface UserDao {
	 boolean regUser(User user) throws Exception;
	 User loginUser(String phone, String pass) throws Exception;
	 String checkRequest(int uid, int tid, int cid)throws Exception;
	 boolean sendReq(int uid,int tid,int cid) throws Exception;
	 ArrayList<PersonInfo> showApprovals(int uid) throws Exception;
	 
	 ArrayList<String> display(int uid, int tid, int cid,int filetype)throws Exception;
}
