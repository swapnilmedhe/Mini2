package com.uday.daoImp;

import static com.uday.dbUtils.MyConnection.getConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.uday.dao.PersonInfoDao;
import com.uday.pojo.PersonInfo;
import com.uday.pojo.User;

public class PersonInfoDaoImp implements PersonInfoDao {
	PreparedStatement ps=null;
	ResultSet rs= null;
	User user =new User();
	static final Logger log = Logger.getLogger(UserDaoImp.class);
	int status=0;
	

	@Override
	public boolean updateProfile(int pid,String fname, String lname, String email, String gender, String addr)
			throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("update person_info set first=?, last=?, gender=?, email=?, address=? where pid=?");
			ps.setInt(6, pid);
			ps.setString(1, fname);
			ps.setString(2, lname);
			ps.setString(3, gender);
			ps.setString(4, email);
			ps.setString(5, addr);
			status = ps.executeUpdate(); 
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally{
			try {
				ps.close();
			} catch (SQLException e) {
				log.error("SQLException in closing PreparedStatement");
			}
		//executing the query
		}
		if(status>0)
		{
			log.info("User updated with name = "+user.getUid());
		return true;
		}
		else
		{
			System.out.println("Updation Failed");
			return false;
		}
	}



	@Override
	public ArrayList<PersonInfo> showTutorCourse() throws Exception {
		ArrayList<PersonInfo> courseList = new ArrayList<>();
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select pid,first,last,course_id, ctitle from person_info,(select tutor_id, tutor_course.course_id, ctitle from tutor_course,course where tutor_course.course_id=course.course_id)as cdetails where pid=cdetails .tutor_id");
			rs = ps.executeQuery(); 
			 while (rs.next()) {
				 PersonInfo pi = new PersonInfo();
				 pi.setTid(rs.getInt(1));
				 pi.setFname(rs.getString(2));
				 pi.setLname(rs.getString(3));
				 pi.setCid(rs.getInt(4));
				 pi.setCname(rs.getString(5));
				 
				 courseList.add(pi);
			      }
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		 finally {
		      try {
		        rs.close();
		        ps.close();
		      } catch (SQLException e) {
		    	  log.error("SQLException in closing PreparedStatement");
		    	  log.error("SQLException in closing ResultSet");
		    	  log.error("SQLException in closing Established Connection");
		      }
		    }

		 return courseList;
	}

}

