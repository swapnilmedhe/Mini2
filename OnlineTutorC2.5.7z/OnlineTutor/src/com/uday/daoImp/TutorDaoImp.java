package com.uday.daoImp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.uday.dao.TutorDao;
import com.uday.pojo.PersonInfo;
import com.uday.pojo.Tutor;
import com.uday.pojo.User;

import static com.uday.dbUtils.MyConnection.*;

public class TutorDaoImp implements TutorDao {

	

	PreparedStatement ps=null;
	ResultSet rs= null;
	Tutor tutor =new Tutor();
	static final Logger log = Logger.getLogger(TutorDaoImp.class);
	int status=0;
	boolean isValid=false;
	
	@Override
	public boolean regTutor(Tutor tutor) throws Exception {
		try (Connection con = getConnection();) {
			isValid =validateMobile(tutor.getPhone());
			if(!isValid){
				ps= con.prepareStatement("insert into tutor (phone, password, qual, exp) values(?,?,?,?)");
				ps.setString(1, tutor.getPhone());
				ps.setString(2, tutor.getPassword());
				ps.setString(3, tutor.getQual());
				ps.setInt(4, tutor.getExp());
				status= ps.executeUpdate(); 
				
				tutor= loginTutor(tutor.getPhone(), tutor.getPassword());
				
				ps= con.prepareStatement("insert into person_info values("+tutor.getTid()+",'','','','','')");
				ps.executeUpdate();
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally{
			try {
				ps.close();
			} catch (SQLException e) {
				log.error("SQLException in closing PreparedStatement");
			}
		//executing the query
		}
		if(status>0 )
		{
			log.info("User registered with name = "+tutor.getPhone());
		return true;
		}
		else
		{
			System.out.println("Registration Failed");
			return false;
		}
	}

	@Override
	public Tutor loginTutor(String phone, String pass)throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select * from tutor where phone=? and password=?");
			ps.setString(1, phone);
			ps.setString(2, pass);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next())
					return new Tutor(rs.getInt(1),rs.getString(2) , rs.getString(3));
			}
			return null;
		}
	}

	@Override
	public ArrayList<PersonInfo> showRequest(int tid) throws Exception {
		ArrayList<PersonInfo> reqList = new ArrayList<>();
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select * from (select tutor_id,user_id,first,course.course_id,ctitle,status from course,(select tutor_id,user_id, first,course_id,status from person_info,request where person_info.pid=request.user_id) as reqdetails where course.course_id=reqdetails.course_id) as checkRequsest where tutor_id=?");
			ps.setInt(1, tid);
			rs = ps.executeQuery(); 
			 while (rs.next()) {
				 reqList.add(new PersonInfo(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getInt(4),rs.getString(5),rs.getString(6)));
			      }
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		 finally {
		      try {
		        rs.close();
		        ps.close();
		      } catch (SQLException e) {
		    	  log.error("SQLException in closing PreparedStatement");
		    	  log.error("SQLException in closing ResultSet");
		    	  log.error("SQLException in closing Established Connection");
		      }
		    }

		 return reqList;
	}

	
	@Override
	public boolean approveReq(int tid, int uid, int cid) throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("update request set status='approved' where tutor_id=? and user_id=? and course_id=?");
			ps.setInt(1, tid);
			ps.setInt(2, uid);
			ps.setInt(3, cid);
			status = ps.executeUpdate();
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally{
			try {
				ps.close();
			} catch (SQLException e) {
				log.error("SQLException in closing PreparedStatement");
			}
		//executing the query
		}
		if(status>0)
		{
			log.info("Req approved by user: "+tid);
		return true;
		}
		else
		{
			System.out.println("Approval Failed");
			return false;
		}
	}

	
	@Override
	public boolean rejectReq(int tid, int uid, int cid) throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("update request set status='rejected' where tutor_id=? and user_id=? and course_id=?");
			ps.setInt(1, tid);
			ps.setInt(2, uid);
			ps.setInt(3, cid);
			status = ps.executeUpdate();
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally{
			try {
				ps.close();
			} catch (SQLException e) {
				log.error("SQLException in closing PreparedStatement");
			}
		//executing the query
		}
		if(status>0)
		{
			log.info("Req rejected by user: "+tid);
		return true;
		}
		else
		{
			System.out.println("Rejection Failed");
			return false;
		}
	}

	@Override
	public Tutor getTutorDetails(String phone, String pass) throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select * from (select pid,exp,first,last,gender,email,qual,phone,password,address from person_info, tutor where person_info.pid = tutor.tutor_id) as tdetails where phone=? and password=?");
			ps.setString(1, phone);
			ps.setString(2, pass);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next())
					return new Tutor(rs.getInt(1),rs.getInt(2) , rs.getString(3), rs.getString(4), rs.getString(5), 
							rs.getString(6), rs.getString(7),rs.getString(8), rs.getString(9),rs.getString(10));
			}
			return null;
		}
	}

	@Override
	public boolean validateMobile(String phone) throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select * from tutor where phone=?");
			ps.setString(1, phone);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next())
					return true;
			}
			return false;
		}
	}



}
