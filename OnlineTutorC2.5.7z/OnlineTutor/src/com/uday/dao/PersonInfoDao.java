package com.uday.dao;

import java.util.ArrayList;

import com.uday.pojo.PersonInfo;

public interface PersonInfoDao {

	boolean updateProfile(int pid, String fname, String lname, String email, String gender, String addr)
			throws Exception;
	ArrayList<PersonInfo> showTutorCourse()throws Exception;
}
