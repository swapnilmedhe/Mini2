package com.uday.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uday.daoImp.PersonInfoDaoImp;
import com.uday.pojo.PersonInfo;

/**
 * Servlet implementation class SortingController
 */
@WebServlet("/SortingController")
public class SortingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SortingController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 response.setContentType("text/html");
		 // PrintWriter out = response.getWriter();
		
		//to load the data on page StartUP
		ServletContext ctx = request.getServletContext();
		PersonInfoDaoImp pinfo = new PersonInfoDaoImp();
		ArrayList<PersonInfo> courseList=null;
		try {
			courseList = pinfo.showTutorCourse();
			ctx.setAttribute("courseList", courseList );
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
