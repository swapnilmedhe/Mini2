package com.uday.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.uday.daoImp.PersonInfoDaoImp;
import com.uday.daoImp.TutorDaoImp;
import com.uday.daoImp.UserDaoImp;
import com.uday.pojo.Tutor;
import com.uday.pojo.User;

/**
 * Servlet implementation class UpdateInfoController
 */
@WebServlet("/UpdateInfoController")
public class UpdateInfoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static final Logger log = Logger.getLogger(RegUser.class);
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateInfoController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
		    PrintWriter out = response.getWriter();
		    Boolean status = false;
		    PersonInfoDaoImp pinfo = new PersonInfoDaoImp();
		    String chkReq=request.getParameter("checkUpdate");
		    String userType = request.getParameter("userType");
		    String fname,lname,email,addr,gender,navPage="";
		    int id;
		    HttpSession session = request.getSession();
		    User user=null;
		    Tutor tutor=null;
		    
		    UserDaoImp daoImp =new UserDaoImp();
		    TutorDaoImp tutdaoImp = new TutorDaoImp();
		    // condition to update personal informations
		    if(chkReq.equals("PersonalInfo"))
		    {
		    	id = Integer.parseInt(request.getParameter("uid"));
		    	fname =request.getParameter("first");
		    	lname =request.getParameter("last");
		    	email =request.getParameter("email");
		    	gender =request.getParameter("gender");
		    	addr =request.getParameter("address");
					try {
						status = pinfo.updateProfile(id, fname, lname, email, gender, addr);
						if (status) {
							if(userType.equals("T")){
								tutor= (Tutor)session.getAttribute("Tutor");
								session.setAttribute("Tutor", tutdaoImp.getTutorDetails(tutor.getPhone(), tutor.getPassword()));
								System.out.println("--------"+(Tutor)session.getAttribute("Tutor")+"---------");
								navPage ="/tutorProfile.jsp";
							}
							else{
								user=(User)session.getAttribute("User");
								session.setAttribute("User", daoImp.getUserDetails(user.getPhone(), user.getPassword()));
								navPage ="/studentProfile.jsp";
							}
							RequestDispatcher rd = getServletContext().getRequestDispatcher(navPage);
							out.println("<font color=green>UPdation successful,.</font>");
							rd.include(request, response);
						} else {
							System.out.println("updation Failed..");
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		    }//ends of personal info if
		    
		  
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

