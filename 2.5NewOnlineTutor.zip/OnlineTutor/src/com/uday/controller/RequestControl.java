package com.uday.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.uday.daoImp.UserDaoImp;
import com.uday.pojo.User;

/**
 * Servlet implementation class RequestControl
 */
@WebServlet("/RequestControl")
public class RequestControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RequestControl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		
		//to check if student has access or not
		HttpSession session = request.getSession();
		User user =(User)session.getAttribute("User");
		String action = request.getParameter("action");
		String status="";
		UserDaoImp userDao=null;
		boolean isReq;
		int tid=0,cid=0;

		userDao = new UserDaoImp();

		tid= Integer.parseInt(request.getParameter("tid"));
		cid= Integer.parseInt(request.getParameter("cid"));
		
		if(user != null){
			if(action.equals("View"))
			{
				try {
					 status = userDao.checkRequest(user.getUid(), tid,cid);
					 System.out.println(status);
					 if(status.equals("pending")){
						 RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentProfile.jsp");
						 out.println("<script type=\"text/javascript\">");
				         out.println("alert('Your request is in pending state. Please wait for tutor approval.');");
				         out.println("</script>");
				         rd.include(request, response);
					 }
				         else if(status.equals("approved")){
				        	 RequestDispatcher rd = getServletContext().getRequestDispatcher("/view.jsp");
					         rd.include(request, response);
				         }
				         
				         else if(status.equals("rejected")){
				        	 RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentProfile.jsp");
							 out.println("<script type=\"text/javascript\">");
					         out.println("alert('Your request has been rejected. You cannot view this page.');");
					         out.println("</script>");
					         rd.include(request, response); 
				         }
					 
					 else{
						 //isReq= userDao.sendReq(user.getUid(),tid,cid);
						 RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentProfile.jsp");
						 out.println("<script type=\"text/javascript\">");
				         out.println("alert('You need to send request for this article. Click on Get Access');");
				         out.println("</script>");
				         rd.include(request, response);
						// System.out.println("Request raised: "+isReq);
					 }
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(action.equals("Get_Access")){
				 try {
					 status = userDao.checkRequest(user.getUid(), tid,cid);
					 if(status.equals("pending") || status.equals("approved"))
					 {
						 RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentProfile.jsp");
						 out.println("<script type=\"text/javascript\">");
				         out.println("alert('Your request is already sent. Check your approvals');");
				         out.println("</script>");
				         rd.include(request, response);
					 }
					 else if(status.equals("rejected")){
						 RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentProfile.jsp");
						 out.println("<script type=\"text/javascript\">");
				         out.println("alert('Your are not allowed to send request again. Your request has been rejected.');");
				         out.println("</script>");
				         rd.include(request, response);
					 }
					 else{
						 isReq= userDao.sendReq(user.getUid(),tid,cid);
						 RequestDispatcher rd = getServletContext().getRequestDispatcher("/studentProfile.jsp");
						 out.println("<script type=\"text/javascript\">");
				         out.println("alert('Your request has been sent to the tutor for approval.');");
				         out.println("</script>");
				         rd.include(request, response);
					 }
						
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				 
			}
		}
		else{
			RequestDispatcher rd = getServletContext().getRequestDispatcher("/home.jsp");
			out.println("<font color=red>"+"Please Login First "+"</font>");
			rd.include(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
