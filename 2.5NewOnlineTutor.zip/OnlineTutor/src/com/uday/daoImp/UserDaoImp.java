package com.uday.daoImp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.uday.dao.UserDao;
import com.uday.pojo.PersonInfo;
import com.uday.pojo.User;
import static com.uday.dbUtils.MyConnection.*;

public class UserDaoImp implements UserDao {
	
	PreparedStatement ps=null;
	ResultSet rs= null;
	User user =new User();
	static final Logger log = Logger.getLogger(UserDaoImp.class);
	int status=0;
	boolean isValid =false;
	@Override
	public boolean regUser(User user) throws Exception {
		try (Connection con = getConnection();) {

			isValid =validateMobile(user.getPhone());
			if(!isValid){
			ps= con.prepareStatement("insert into user (phone, password) values(?,?)");
			ps.setString(1, user.getPhone());
			ps.setString(2, user.getPassword());
			status= ps.executeUpdate();
			
			user= loginUser(user.getPhone(), user.getPassword());
			ps= con.prepareStatement("insert into person_info values("+user.getUid()+",'','','','','')");
			ps.executeUpdate(); 
			}
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally{
			try {
				ps.close();
			} catch (SQLException e) {
				log.error("SQLException in closing PreparedStatement");
			}
		//executing the query
		}
		if(status>0)
		{
			log.info("User registered with name = "+user.getUid());
		return true;
		}
		else
		{
			System.out.println("Registration Failed");
			return false;
		}
	}

	
	@Override
	public User loginUser(String phone, String pass) throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select * from user where phone=? and password=?");
			ps.setString(1, phone);
			ps.setString(2, pass);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next())
					return new User(rs.getInt(1),rs.getString(2), rs.getString(3));
			}
			return null;
		}
	}


	
	
	@Override
	public String checkRequest(int uid, int tid, int cid) throws Exception {
		String status = "";
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select status from request where tutor_id=? and user_id=? and course_id=?");
			ps.setInt(1, tid);
			ps.setInt(2, uid);
			ps.setInt(3, cid);
			rs = ps.executeQuery(); 
			 while (rs.next()) {
				status = rs.getString(1);
			      }
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		 finally {
		      try {
		        rs.close();
		        ps.close();
		      } catch (SQLException e) {
		    	  log.error("SQLException in closing PreparedStatement");
		    	  log.error("SQLException in closing ResultSet");
		    	  log.error("SQLException in closing Established Connection");
		      }
		    }

		 return status;
		
	}


	@Override
	public boolean sendReq(int uid, int tid, int cid) throws Exception {
		try (Connection con = getConnection();) {
			
			ps= con.prepareStatement("insert into request values(?,?,?,?)");
			ps.setInt(1, tid);
			ps.setInt(2, uid);
			ps.setInt(3, cid);
			ps.setString(4, "pending");
			status = ps.executeUpdate(); 
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally{
			try {
				ps.close();
			} catch (SQLException e) {
				log.error("SQLException in closing PreparedStatement");
			}
		//executing the query
		}
		if(status>0)
		{
			log.info("User has raised a req for tutor: "+tid+" and course:"+cid);
		return true;
		}
		else
		{
			log.info("request for course failed ");
			return false;
		}
	}



	@Override
	public ArrayList<PersonInfo> showApprovals(int uid) throws Exception {
		ArrayList<PersonInfo> reqList = new ArrayList<>();
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select first,last,ctitle,status from (select tutor_id,user_id,first,last,course.course_id,ctitle,status from course,(select tutor_id,user_id,first,last,course_id,status from person_info,request where person_info.pid=request.tutor_id) as reqdetails where course.course_id=reqdetails.course_id) as checkRequsest where user_id=?");
			ps.setInt(1, uid);
			rs = ps.executeQuery(); 
			 while (rs.next()) {
				 reqList.add(new PersonInfo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
			      }
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		 finally {
		      try {
		        rs.close();
		        ps.close();
		      } catch (SQLException e) {
		    	  log.error("SQLException in closing PreparedStatement");
		    	  log.error("SQLException in closing ResultSet");
		    	  log.error("SQLException in closing Established Connection");
		      }
		    }

		 return reqList;
	}


	@Override
	public User getUserDetails(String phone, String pass) throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select * from (select pid,first,last,gender,email,phone,password,address from person_info, user  where person_info.pid = user.uid) as udetails where phone=? and password=?");
			ps.setString(1, phone);
			ps.setString(2, pass);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next())
					return new User(rs.getInt(1),rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8));
			}
			return null;
		}
	}


	@Override
	public boolean validateMobile(String phone) throws Exception {
		try (Connection con = getConnection();) {
			ps= con.prepareStatement("select * from user where phone=?");
			ps.setString(1, phone);
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next())
					return true;
			}
			return false;
		}
	}
	
	
	
	public ArrayList<String> display(int uid, int tid, int cid, int filetype) throws Exception {
		ArrayList<String> allFiles = new ArrayList<>();
			try (Connection con = getConnection();) {
			
			ps= con.prepareStatement("select filedata from (select request.tutor_id, request.course_id, user_id, filetype,filedata from request,tutor_course where tutor_course.course_id = ? )as cdetails where tutor_id=? and user_id=? and course_id=?;");
			ps.setInt(1, cid);
			ps.setInt(2, tid);
			ps.setInt(3, uid);
			ps.setInt(4, cid);
			
			ResultSet urequestdata = ps.executeQuery(); 
			while(urequestdata.next())
			{
				allFiles.add(urequestdata.getString(1));
			}
		
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		finally{
			try {
				ps.close();
			} catch (SQLException e) {
				log.error("SQLException in closing PreparedStatement");
				System.out.println("data");
			}
		//executing the query
		}
		return allFiles;
		//return "fail to ";
	}


}

