package com.surfer.File;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayImage
 */
@WebServlet("/DisplayImage")
public class DisplayImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayImage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		  int showFile=Integer.parseInt(request.getParameter("showFile")); 
        ServletOutputStream sos;
        Connection  con=null;
        PreparedStatement pstmt=null;
         
        if(showFile==1){
       	 response.setContentType("image/jpeg");

      // response.setHeader("Content-disposition","inline; filename="+bookId+".pdf" );


        sos = response.getOutputStream();
        

          try {
              Class.forName("com.mysql.jdbc.Driver");
              con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
         } catch (Exception e) {
                    System.out.println(e);
                    System.exit(0); 
                         }
           
         ResultSet rset=null;
           try {
           /*    pstmt = con.prepareStatement("Select imagecontent from image where imgid=?");*/
           	 pstmt = con.prepareStatement("Select filedata from tutor_course where filetype=1 ");
              // pstmt.setString(1, imgid.trim());
               rset = pstmt.executeQuery();
               if (rset.next())
                   sos.write(rset.getBytes("filedata"));
               else
                   return;
                
           } catch (SQLException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
           }
    
       sos.flush();
       sos.close();
        
	
	}/*end of  if  fileimage*/
	if(showFile==2)
	{
		
		 
	        response.setContentType("application/pdf");
	 
	       // response.setHeader("Content-disposition","inline; filename="+bookId+".pdf" );
	        response.setHeader("Content-disposition","inline; filename="+""+".pdf" );
	         sos = response.getOutputStream();
	         
	           try {
	               Class.forName("com.mysql.jdbc.Driver");
	               con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","root");
	          } catch (Exception e) {
	                     System.out.println(e);
	                     System.exit(0); 
	                          }
	            
	          ResultSet rset=null;
	            try {
	                pstmt = con.prepareStatement("Select filedata from tutor_course where filetype=2 ");
	            
	                rset = pstmt.executeQuery();
	                if (rset.next())
	                    sos.write(rset.getBytes("filedata"));
	                else
	                    return;
	                 
	            } catch (SQLException e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
	     
	        sos.flush();
	        sos.close();
	         
	    }
		
	}
	

}

